from src.report_service import build_user_report, build_admin_report

def test_reports_have_same_format():
    person = {
        "name": "Ivan",
        "email": "ivan@example.com",
        "role": "admin",
        "active": True
    }
    assert build_user_report(person) == build_admin_report(person)

def test_report_contains_fields():
    person = {
        "name": "Ivan",
        "email": "ivan@example.com",
        "role": "user",
        "active": True
    }
    report = build_user_report(person)
    assert "Name: Ivan" in report
    assert "Email: ivan@example.com" in report
    assert "Role: user" in report
