from src.order_service import process_order

def test_regular_order():
    order = {"items": [{"price": 100, "quantity": 2}]}
    customer = {"name": "Ivan", "type": "regular", "country": "RU"}
    result = process_order(order, customer)
    assert result["ok"] is True
    assert result["total"] == 500

def test_vip_large_order():
    order = {"items": [{"price": 6000, "quantity": 2}]}
    customer = {"name": "Anna", "type": "vip", "country": "RU"}
    result = process_order(order, customer)
    assert result["total"] == 9900

def test_premium_express():
    order = {"items": [{"price": 1000, "quantity": 2}]}
    customer = {"name": "Oleg", "type": "premium", "country": "RU"}
    result = process_order(order, customer, express=True)
    assert result["total"] == 2600

def test_country_surcharge():
    order = {"items": [{"price": 1000, "quantity": 1}]}
    customer = {"name": "Emma", "type": "regular", "country": "NL"}
    result = process_order(order, customer)
    assert result["total"] == 1550

def test_missing_order():
    result = process_order(None, {"name": "A", "type": "regular"})
    assert result == {"ok": False, "total": 0, "message": "Order is required"}

def test_empty_items():
    result = process_order({"items": []}, {"name": "A", "type": "regular"})
    assert result["ok"] is False
    assert result["message"] == "Order has no items"
