import pytest
from src.user_service import UserService

def test_register_user_normalizes_email():
    service = UserService()
    user = service.register_user(" Ivan ", "IVAN@EXAMPLE.COM", "user")
    assert user["name"] == "Ivan"
    assert user["email"] == "ivan@example.com"
    assert user["active"] is True

def test_invalid_email():
    service = UserService()
    with pytest.raises(ValueError):
        service.register_user("Ivan", "invalid", "user")

def test_deactivate_user():
    service = UserService()
    service.register_user("Admin", "admin@example.com", "admin")
    assert service.deactivate_user("ADMIN@EXAMPLE.COM") is True
    assert service.users[0]["active"] is False

def test_get_active_admin_emails():
    service = UserService()
    service.register_user("Admin", "admin@example.com", "admin")
    service.register_user("User", "user@example.com", "user")
    assert service.get_active_admin_emails() == ["admin@example.com"]
