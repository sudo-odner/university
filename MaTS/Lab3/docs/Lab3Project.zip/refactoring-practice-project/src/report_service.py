def build_user_report(user):
    result = []
    result.append("--------------------")
    result.append("REPORT")
    result.append("--------------------")
    result.append("Name: " + str(user.get("name", "")))
    result.append("Email: " + str(user.get("email", "")))
    result.append("Role: " + str(user.get("role", "")))
    result.append("Active: " + str(user.get("active", False)))
    result.append("--------------------")
    result.append("END")
    result.append("--------------------")
    return "\n".join(result)


def build_admin_report(admin):
    result = []
    result.append("--------------------")
    result.append("REPORT")
    result.append("--------------------")
    result.append("Name: " + str(admin.get("name", "")))
    result.append("Email: " + str(admin.get("email", "")))
    result.append("Role: " + str(admin.get("role", "")))
    result.append("Active: " + str(admin.get("active", False)))
    result.append("--------------------")
    result.append("END")
    result.append("--------------------")
    return "\n".join(result)
