VIP_LIMIT = 10000

def process_order(order, customer, express=False):
    result = {"ok": False, "total": 0, "message": ""}

    if order is not None:
        if customer is not None:
            if "items" in order:
                if len(order["items"]) > 0:
                    total = 0
                    for item in order["items"]:
                        total = total + item["price"] * item["quantity"]

                    d = 0
                    if customer["type"] == "vip":
                        if total > 10000:
                            d = 0.20
                        else:
                            d = 0.10
                    else:
                        if customer["type"] == "premium":
                            d = 0.05
                        else:
                            d = 0

                    discount_value = total * d
                    total = total - discount_value

                    delivery = 300
                    if express == True:
                        delivery = 700

                    if total >= 15000:
                        delivery = 0

                    total = total + delivery

                    if customer.get("country") == "NL":
                        total = total + 250
                    elif customer.get("country") == "DE":
                        total = total + 220
                    elif customer.get("country") == "FR":
                        total = total + 230

                    message = "Order for " + customer["name"] + ": " + str(round(total, 2))
                    print(message)

                    result["ok"] = True
                    result["total"] = round(total, 2)
                    result["message"] = message
                else:
                    result["message"] = "Order has no items"
            else:
                result["message"] = "Order has no items"
        else:
            result["message"] = "Customer is required"
    else:
        result["message"] = "Order is required"

    return result
