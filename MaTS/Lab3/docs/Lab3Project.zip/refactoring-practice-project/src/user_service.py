class UserService:
    def __init__(self):
        self.users = []

    def register_user(self, name, email, role, active=True):
        if name is None or name.strip() == "":
            raise ValueError("Name is required")

        if email is None or "@" not in email:
            raise ValueError("Email is invalid")

        if role != "user" and role != "admin" and role != "manager":
            raise ValueError("Role is invalid")

        user = {
            "name": name.strip(),
            "email": email.strip().lower(),
            "role": role,
            "active": active
        }

        self.users.append(user)

        subject = "Welcome, " + user["name"]
        body = "Account " + user["email"] + " was created with role " + user["role"]

        print("EMAIL TO:", user["email"])
        print("SUBJECT:", subject)
        print("BODY:", body)

        return user

    def deactivate_user(self, email):
        for user in self.users:
            if user["email"] == email.lower():
                user["active"] = False

                subject = "Account deactivated"
                body = "Account " + user["email"] + " was deactivated"

                print("EMAIL TO:", user["email"])
                print("SUBJECT:", subject)
                print("BODY:", body)

                return True
        return False

    def get_active_admin_emails(self):
        result = []
        for user in self.users:
            if user["active"] == True:
                if user["role"] == "admin":
                    result.append(user["email"])
        return result
