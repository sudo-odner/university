from decimal import Decimal

from src.inventory import choose_warehouse, reserve_items, stock_state
from src.pricing import calculate_order_total, calculate_refund_amount
from src.users import normalize_user, resolve_permission
from src.validation import validate_email, validate_order_payload


def test_regular_order_total():
    assert calculate_order_total(100, 2, "regular", country="RU") == Decimal("500.00")


def test_vip_discount():
    assert calculate_order_total(6000, 2, "vip", country="RU") == Decimal("9900.00")


def test_premium_discount():
    assert calculate_order_total(1000, 2, "premium", country="RU") == Decimal("2200.00")


def test_promo_code():
    assert calculate_order_total(1000, 2, "regular", promo_code="SALE500", country="RU") == Decimal("1800.00")


def test_refund():
    assert calculate_refund_amount(1000, 10, False, "defect") == Decimal("950")


def test_normalize_user():
    user = normalize_user({"name": " Ivan ", "email": "IVAN@example.com", "role": "Customer"})
    assert user["name"] == "Ivan"
    assert user["email"] == "ivan@example.com"
    assert user["role"] == "customer"


def test_permissions():
    assert resolve_permission({"role": "admin"}, "delete") is True
    assert resolve_permission({"role": "customer"}, "write") is False


def test_validation():
    assert validate_email("user@example.com") is True
    assert validate_email("wrong") is False
    assert validate_order_payload({"price": 10, "quantity": 1, "customer_type": "regular", "country": "RU"}) == []


def test_inventory():
    stock = {"main": 10, "backup": 4}
    assert choose_warehouse(stock, "missing") == "main"
    assert reserve_items(stock, 3, "main")["reserved"] == 3
    assert stock_state(4) == "low"
