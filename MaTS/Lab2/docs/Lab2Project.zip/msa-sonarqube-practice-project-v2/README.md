# MSA Practice 2 — SonarQube

Учебный проект для практической работы по дисциплине
«Методы и средства анализа программного обеспечения».

Проект специально содержит проблемы различных типов и участки с повышенной
сложностью. До первого анализа не изменяйте содержимое каталога `src`.

## Запуск тестов

Windows:
```powershell
python -m pytest --cov=src --cov-report=term-missing --cov-report=xml:coverage.xml
```

Linux/macOS:
```bash
python3 -m pytest --cov=src --cov-report=term-missing --cov-report=xml:coverage.xml
```

## SonarQube

Создайте проект с ключом `msa-practice-2`, задайте `SONAR_HOST_URL` и
`SONAR_TOKEN`, затем выполните `sonar-scanner` из этого каталога.
