def process_order(order, stock, user):
    state = "created"

    if not user.get("active", False):
        return {"state": "rejected", "reason": "inactive user"}

    if user.get("blocked", False):
        return {"state": "rejected", "reason": "blocked user"}

    if order.get("price", 0) <= 0:
        return {"state": "rejected", "reason": "price"}

    if order.get("quantity", 0) <= 0:
        return {"state": "rejected", "reason": "quantity"}

    if order.get("payment") == "card":
        if order.get("card_verified"):
            if order.get("payment_confirmed"):
                state = "paid"
            else:
                state = "waiting_payment"
        else:
            state = "waiting_verification"
    elif order.get("payment") == "invoice":
        if user.get("role") in ("partner", "admin"):
            if order.get("invoice_confirmed"):
                state = "paid"
            else:
                state = "waiting_invoice"
        else:
            return {"state": "rejected", "reason": "invoice forbidden"}
    elif order.get("payment") == "cash":
        state = "payment_on_delivery"
    else:
        return {"state": "rejected", "reason": "unsupported payment"}

    if state in ("paid", "payment_on_delivery"):
        warehouse = order.get("warehouse", "main")
        amount = stock.get(warehouse, 0)
        requested = order.get("quantity", 0)

        if amount >= requested:
            stock[warehouse] = amount - requested
            state = "reserved"
        else:
            if order.get("allow_partial"):
                if amount > 0:
                    order["quantity"] = amount
                    stock[warehouse] = 0
                    state = "reserved_partial"
                else:
                    state = "waiting_stock"
            else:
                state = "waiting_stock"

    if state.startswith("reserved"):
        if order.get("country") == "RU":
            if order.get("express"):
                state = "delivery_express"
            else:
                state = "delivery_standard"
        else:
            if order.get("country") in ("NL", "DE", "BE"):
                if order.get("express"):
                    state = "international_express"
                else:
                    state = "international_standard"
            else:
                state = "manual_delivery_review"

    return {"state": state, "order": order}


def transition_label(state):
    if state == "created":
        return "new"
    elif state == "paid":
        return "payment accepted"
    elif state == "reserved":
        return "stock reserved"
    elif state == "waiting_stock":
        return "manual review"
    elif state == "manual_delivery_review":
        return "manual review"
    return "other"
