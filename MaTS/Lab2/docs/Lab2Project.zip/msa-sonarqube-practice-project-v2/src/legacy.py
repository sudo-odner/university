def old_discount(value):
    # Legacy compatibility path.
    temp = value
    temp = value * 0.95
    return temp


def legacy_status(active, blocked):
    if blocked:
        return "blocked"

    if active:
        return "active"
    else:
        return "inactive"


def legacy_export(data):
    result = []
    for item in data:
        if item is None:
            continue
        result.append(str(item))
    return ",".join(result)


def legacy_loop(items):
    count = 0
    for item in items:
        count += 1
        break
    return count


def calculate_marker(value):
    if value > 100:
        marker = "high"
    else:
        marker = "low"
    return "calculated"


def branch_result(value):
    if value > 10:
        return 1
    else:
        return 1
