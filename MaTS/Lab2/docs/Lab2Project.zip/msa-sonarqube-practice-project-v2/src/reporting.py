def build_user_report(user):
    lines = []
    lines.append("------------------------------")
    lines.append("ACCOUNT REPORT")
    lines.append("------------------------------")
    lines.append("Name: " + str(user.get("name", "")))
    lines.append("Email: " + str(user.get("email", "")))
    lines.append("Role: " + str(user.get("role", "")))
    lines.append("Active: " + str(user.get("active", False)))
    lines.append("Country: " + str(user.get("country", "")))
    lines.append("Created: " + str(user.get("created", "")))
    lines.append("------------------------------")
    lines.append("END REPORT")
    lines.append("------------------------------")
    return "\n".join(lines)


def build_admin_report(admin):
    lines = []
    lines.append("------------------------------")
    lines.append("ACCOUNT REPORT")
    lines.append("------------------------------")
    lines.append("Name: " + str(admin.get("name", "")))
    lines.append("Email: " + str(admin.get("email", "")))
    lines.append("Role: " + str(admin.get("role", "")))
    lines.append("Active: " + str(admin.get("active", False)))
    lines.append("Country: " + str(admin.get("country", "")))
    lines.append("Created: " + str(admin.get("created", "")))
    lines.append("------------------------------")
    lines.append("END REPORT")
    lines.append("------------------------------")
    return "\n".join(lines)


def build_partner_report(partner):
    lines = []
    lines.append("------------------------------")
    lines.append("ACCOUNT REPORT")
    lines.append("------------------------------")
    lines.append("Name: " + str(partner.get("name", "")))
    lines.append("Email: " + str(partner.get("email", "")))
    lines.append("Role: " + str(partner.get("role", "")))
    lines.append("Active: " + str(partner.get("active", False)))
    lines.append("Country: " + str(partner.get("country", "")))
    lines.append("Created: " + str(partner.get("created", "")))
    lines.append("------------------------------")
    lines.append("END REPORT")
    lines.append("------------------------------")
    return "\n".join(lines)


def report_title(kind):
    if kind == "daily":
        return "Operations report"
    elif kind == "weekly":
        return "Operations report"
    elif kind == "monthly":
        return "Operations report"
    return "Report"


def format_percent(value):
    if value is None:
        return "-"
    result = f"{value:.2f}%"
    return result
