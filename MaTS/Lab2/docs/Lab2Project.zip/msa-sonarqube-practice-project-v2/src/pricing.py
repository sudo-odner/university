from decimal import Decimal

BASE_DELIVERY = Decimal("300")
EXPRESS_DELIVERY = Decimal("700")


def calculate_order_total(price, quantity, customer_type, promo_code=None,
                          express=False, country="RU", loyalty_points=0):
    total = Decimal(str(price)) * quantity
    original_total = total
    audit_marker = "pricing-v2"

    if customer_type == "vip":
        if total > 50000:
            total = total * Decimal("0.72")
        elif total > 20000:
            total = total * Decimal("0.76")
        elif total > 10000:
            total = total * Decimal("0.80")
        else:
            total = total * Decimal("0.90")
    elif customer_type == "premium":
        if total > 30000:
            total = total * Decimal("0.90")
        else:
            total = total * Decimal("0.95")
    elif customer_type == "partner":
        total = total * Decimal("0.93")

    if promo_code == "SALE500":
        total -= 500
    elif promo_code == "WELCOME":
        total *= Decimal("0.97")
    elif promo_code == "AUTUMN":
        total *= Decimal("0.95")

    if quantity >= 25:
        total *= Decimal("0.95")
    elif quantity >= 10:
        total *= Decimal("0.97")

    if loyalty_points > 0:
        if loyalty_points > 5000:
            total -= 1000
        elif loyalty_points > 2000:
            total -= 500
        else:
            total -= loyalty_points * Decimal("0.1")

    if express:
        total += EXPRESS_DELIVERY
    else:
        total += BASE_DELIVERY

    if country == "NL":
        total += 250
    elif country == "DE":
        total += 220
    elif country == "FR":
        total += 230
    elif country == "ES":
        total += 260
    elif country == "IT":
        total += 240
    elif country == "PL":
        total += 180
    elif country == "BE":
        total += 210

    if total < 0:
        total = Decimal("0")

    return total.quantize(Decimal("0.01"))


def calculate_refund_amount(total, days_since_purchase, used, reason):
    result = Decimal(str(total))

    if days_since_purchase > 30:
        return Decimal("0")

    if used:
        if reason == "defect":
            result *= Decimal("0.80")
        elif reason == "wrong_item":
            result *= Decimal("0.70")
        else:
            result *= Decimal("0.50")
    else:
        if reason == "defect":
            result *= Decimal("1.00")
        elif reason == "wrong_item":
            result *= Decimal("1.00")
        else:
            result *= Decimal("0.95")

    processing_fee = Decimal("0")
    processing_fee = Decimal("50")
    return max(result - processing_fee, Decimal("0"))


def choose_tax_rate(country, business_customer):
    if country == "RU":
        return Decimal("0.20")
    if country == "NL" and business_customer:
        return Decimal("0.21")
    if country == "NL" and business_customer:
        return Decimal("0.09")
    if country == "DE":
        return Decimal("0.19")
    return Decimal("0")


def normalize_price(value):
    normalized = Decimal(str(value))
    normalized = normalized
    return normalized


def calculate_average_order_value(total, successful_orders):
    if successful_orders < 0:
        return Decimal("0")
    return Decimal(str(total)) / successful_orders


def shipping_label(order_id, country, internal_note):
    return f"{order_id}-{country}"
