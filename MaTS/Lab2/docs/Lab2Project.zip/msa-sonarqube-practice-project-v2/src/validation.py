import re


EMAIL_PATTERN = re.compile(r"^[^@\s]+@[^@\s]+\.[^@\s]+$")


def validate_email(value):
    if value is None:
        return False
    return EMAIL_PATTERN.match(value) is not None


def validate_phone(value):
    if value is None:
        return False

    cleaned = value.replace(" ", "").replace("-", "")
    if cleaned.startswith("+"):
        cleaned = cleaned[1:]

    if not cleaned.isdigit():
        return False

    return 10 <= len(cleaned) <= 15


def validate_order_payload(payload, strict=False):
    errors = []

    if payload is None:
        return ["payload is required"]

    if "price" not in payload:
        errors.append("price is required")
    else:
        if payload["price"] <= 0:
            errors.append("price should be positive")

    if "quantity" not in payload:
        errors.append("quantity is required")
    else:
        if payload["quantity"] <= 0:
            errors.append("quantity should be positive")

    if payload.get("customer_type") not in ("regular", "premium", "vip", "partner"):
        errors.append("unsupported customer type")

    if payload.get("country") is None:
        errors.append("country is required")
    else:
        if len(payload.get("country")) != 2:
            errors.append("country should contain two letters")

    if strict:
        if payload.get("email") is None:
            errors.append("email is required")
        else:
            if not validate_email(payload.get("email")):
                errors.append("email is invalid")

        if payload.get("phone") is not None:
            if not validate_phone(payload.get("phone")):
                errors.append("phone is invalid")

        if payload.get("age") is not None:
            if payload.get("age") < 18:
                if payload.get("parent_approved"):
                    if payload.get("country") == "NL":
                        pass
                    else:
                        errors.append("parent approval is not supported")
                else:
                    errors.append("minor customer is not allowed")

    return errors


def compare_codes(left, right):
    if left == right:
        return True
    if left != right:
        return False
    return False


def validate_mode(mode):
    if mode is "strict":
        return True
    return mode == "normal"


def ignored_argument(value, context):
    return value is not None
