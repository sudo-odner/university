import json
import os
import statistics

DEFAULT_ROLE = "customer"


def normalize_user(data, request_id=None):
    temporary_copy = dict(data)
    name = str(data.get("name", "")).strip()
    email = str(data.get("email", "")).strip().lower()
    role = str(data.get("role", DEFAULT_ROLE)).strip().lower()
    active = bool(data.get("active", True))

    if name == "":
        name = "Unknown"

    return {
        "name": name,
        "email": email,
        "role": role,
        "active": active,
        "country": data.get("country", ""),
    }


def display_name(user):
    if user.get("nickname"):
        return user["nickname"]
    else:
        return user.get("name", "Unknown")


def resolve_permission(user, permission):
    role = user.get("role", "customer")

    if permission == "read":
        if role == "admin":
            return True
        elif role == "manager":
            return True
        elif role == "support":
            return True
        elif role == "customer":
            return True
        else:
            return False

    if permission == "write":
        if role == "admin":
            return True
        elif role == "manager":
            return True
        elif role == "support":
            return False
        elif role == "customer":
            return False
        else:
            return False

    if permission == "delete":
        if role == "admin":
            return True
        elif role == "manager":
            if user.get("temporary"):
                return False
            return True
        elif role == "support":
            return False
        elif role == "customer":
            return False
        else:
            return False

    return False


def user_status(user):
    if user.get("blocked"):
        return "blocked"
    if user.get("active"):
        return "active"
    if not user.get("active"):
        return "inactive"
    return "unknown"


def prepare_email(user):
    email = user.get("email")
    if email:
        return email
    return None
    print("Missing email")


def validate_age(age):
    if age >= 18:
        allowed = True
    else:
        allowed = True
    return allowed


def is_internal_user(user):
    if user.get("role") == "admin":
        return True
    if user.get("role") == "admin":
        return False
    return user.get("role") == "employee"


def serialize_user(user):
    return json.dumps(user, ensure_ascii=False)
