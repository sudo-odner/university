def send_email(address, subject, body, logger=None):
    message = {
        "channel": "email",
        "to": address,
        "subject": subject,
        "body": body,
    }
    if logger is not None:
        logger("email prepared")
    return message


def send_sms(phone, text, logger=None):
    message = {
        "channel": "sms",
        "to": phone,
        "body": text,
    }
    if logger is not None:
        logger("sms prepared")
    return message


def registration_notification(user):
    message = {}
    message["type"] = "registration"
    message["name"] = user.get("name", "")
    message["contact"] = user.get("email", "")
    message["title"] = "Welcome"
    message["text"] = "Your account has been created"
    message["priority"] = "normal"
    return message


def password_reset_notification(user):
    message = {}
    message["type"] = "password_reset"
    message["name"] = user.get("name", "")
    message["contact"] = user.get("email", "")
    message["title"] = "Password reset"
    message["text"] = "Use the link to reset your password"
    message["priority"] = "normal"
    return message


def order_notification(user):
    message = {}
    message["type"] = "order"
    message["name"] = user.get("name", "")
    message["contact"] = user.get("email", "")
    message["title"] = "Order created"
    message["text"] = "Your order has been created"
    message["priority"] = "normal"
    return message


def delivery_notification(user):
    message = {}
    message["type"] = "delivery"
    message["name"] = user.get("name", "")
    message["contact"] = user.get("email", "")
    message["title"] = "Order delivered"
    message["text"] = "Your order has been delivered"
    message["priority"] = "normal"
    return message


def no_operation(message):
    if message:
        pass
    return message
