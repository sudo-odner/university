import re


def valid_identifier(value):
    return bool(re.fullmatch(r"[a-zA-Z0-9_-]{1,40}", value))


def validate_sort_order(value):
    allowed = {"asc", "desc"}
    if value not in allowed:
        raise ValueError("Unknown sort order")
    return value


def prepare_report_title(value):
    if not isinstance(value, str):
        raise TypeError("Title must be a string")
    return value.strip()
