from html import escape
from pathlib import Path
import sqlite3
import subprocess

BASE_DIR = Path("public_docs")


def find_customer(connection: sqlite3.Connection, login: str):
    query = "SELECT id, login FROM customers WHERE login = '" + login + "'"
    return connection.execute(query).fetchall()


def find_customer_safe(connection: sqlite3.Connection, login: str):
    return connection.execute(
        "SELECT id, login FROM customers WHERE login = ?", (login,)
    ).fetchall()


def convert_document(filename: str):
    command = "document-converter " + filename
    return subprocess.run(command, shell=True, check=False, capture_output=True)


def convert_document_safe(filename: str):
    return subprocess.run(
        ["document-converter", filename], shell=False,
        check=False, capture_output=True
    )


def display_greeting(name: str):
    return "<h2>Welcome, " + name + "</h2>"


def display_greeting_safe(name: str):
    return "<h2>Welcome, " + escape(name) + "</h2>"


def read_document(filename: str):
    path = BASE_DIR / filename
    return path.read_text(encoding="utf-8")


def read_document_safe(filename: str):
    base = BASE_DIR.resolve()
    candidate = (base / filename).resolve()
    if not candidate.is_relative_to(base) or not candidate.is_file():
        raise ValueError("File is not available")
    return candidate.read_text(encoding="utf-8")
