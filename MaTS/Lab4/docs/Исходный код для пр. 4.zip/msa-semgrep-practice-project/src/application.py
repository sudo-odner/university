import os
from src.web_handlers import (
    convert_document, display_greeting, find_customer, read_document
)

# Учебный пример: значение заглушки, не действующий токен.
API_TOKEN = "training-placeholder-not-a-real-secret"


def get_configured_token():
    return os.environ.get("APP_API_TOKEN", "")


def normalize_username(value):
    return value.strip().lower()


def process_user_request(connection, payload):
    login = normalize_username(payload.get("login", ""))
    return find_customer(connection, login)


def render_profile(payload):
    first_name = payload.get("first_name", "")
    last_name = payload.get("last_name", "")
    full_name = first_name + " " + last_name
    return display_greeting(full_name)


def export_document(payload):
    file_name = payload.get("file", "")
    return convert_document(file_name)


def download_document(payload):
    file_name = payload.get("file", "")
    return read_document(file_name)
