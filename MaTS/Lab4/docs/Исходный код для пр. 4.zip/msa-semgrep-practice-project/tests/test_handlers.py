import sqlite3
from html import escape
from src.web_handlers import find_customer_safe, display_greeting_safe
from src.validation import valid_identifier, validate_sort_order


def test_parameterized_lookup():
    conn = sqlite3.connect(":memory:")
    conn.execute("CREATE TABLE customers (id INTEGER, login TEXT)")
    conn.execute("INSERT INTO customers VALUES (1, 'anna')")
    assert find_customer_safe(conn, "anna") == [(1, "anna")]
    assert find_customer_safe(conn, "missing") == []


def test_safe_output_is_escaped():
    name = "Alice & Bob"
    assert display_greeting_safe(name) == "<h2>Welcome, " + escape(name) + "</h2>"


def test_valid_identifier():
    assert valid_identifier("user_14")
    assert not valid_identifier("user with spaces")


def test_sort_order():
    assert validate_sort_order("asc") == "asc"
