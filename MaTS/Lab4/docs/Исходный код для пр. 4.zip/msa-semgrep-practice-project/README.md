# Практическая работа №4: SAST и Semgrep CE

Учебный проект с намеренно небезопасными примерами. Не использовать в production.
Все данные и токены фиктивные; работайте локально. Не запускайте функции,
в которых используются оболочка и пользовательские пути, с непроверенным вводом.

Команды из корня проекта:

- `python -m pytest -q`
- `semgrep scan --config rules/unsafe-python-patterns.yml src`
- `semgrep scan --config auto src` (для community rules может понадобиться интернет)
- `semgrep scan --config rules/unsafe-python-patterns.yml --json --output semgrep-results.json src`

В `src/web_handlers.py` есть как небезопасные, так и безопасные варианты для сравнения.
Количество findings зависит от версии Semgrep и набора правил. Указанный custom
ruleset нацелен на учебную проверку, а не на полноту security-аудита.
